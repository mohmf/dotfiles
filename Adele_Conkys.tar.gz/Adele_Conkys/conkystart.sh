#!/bin/bash
sleep 10
conky -b -c /home/mohmf/.conky/Adele_Conkys/adele_conky &
